import java.util.*;
public class Collection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//creating arraylist
				System.out.println("ArrayList");
				ArrayList<String> name=new ArrayList<String>();   
			      name.add("Krishna");//
			      name.add("Ram");    	   
			      System.out.println(name);  
			      System.out.println("\n");
				
				//creating linkedlist
			      System.out.println("LinkedList");
			      LinkedList<Integer> num =new LinkedList<Integer>();  
			      num.add(50);  
			      num.add(100);  	      
			      Iterator<Integer> iter=num.iterator();  
			      while(iter.hasNext()){  
			       System.out.println(iter.next());
			       System.out.println("\n");
			       
			     //creating vector
				      System.out.println("Vector");
				      Vector<Integer> v = new Vector();
				      v.addElement(50); 
				      v.addElement(100); 
				      System.out.println(v);
				      System.out.println("\n");
			       
			       //creating hashset
			       System.out.println("HashSet");
			       HashSet<String> h=new HashSet<String>();  
			       h.add("1");  
			       h.add("2");  
			       h.add("3");
			       System.out.println(h);
			       System.out.println("\n");
			       
			       //creating linkedhashset
			       System.out.println("LinkedHashSet");
			       LinkedHashSet<Integer> hs=new LinkedHashSet<Integer>();  
			       hs.add(55);  
			       hs.add(58);  
			       hs.add(56);	       
			       System.out.println(hs);
			      	} 
	}

}
