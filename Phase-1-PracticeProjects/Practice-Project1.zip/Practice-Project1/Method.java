
public class Method {
	
	//method
	public int multiplynumbers(int a,int b)
	{
		int c=a*b;
		return c;
	}
	
	// method overloading
	public void area(int b, int h)
	{
		System.out.println("Area of triangle = "+(0.5*b*h));
	}
	public void area(int r)
	{
		System.out.println("Area of cirlce = "+(3.14*r*r));
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Method obj = new Method();
		int d = obj.multiplynumbers(10, 3);
		obj.area(2, 4);
		obj.area(5);
		System.out.println("Multiplication is : "+d);

	}

}
