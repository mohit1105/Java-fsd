import java.util.*;
import java.util.regex.*;
public class RegularExpression {
	public static void main(String[] args) {

		String pattern = "[a-z]+";
		String str = "Always Alone";
		Pattern p = Pattern.compile(pattern);
		Matcher c = p.matcher(str);
		
		while (c.find())
	      	System.out.println( str.substring( c.start(), c.end() ) );
		}


}
