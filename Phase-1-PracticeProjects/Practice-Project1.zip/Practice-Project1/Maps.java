import java.util.*;
public class Maps {
	public static void main(String[] args)
	{
		        //Hashmap
		
				HashMap<String,Integer> hm=new HashMap<String,Integer>();      
			      hm.put("Aman",1);    
			      hm.put("Naman",2);       
			       
			      System.out.println("\nThe elements of hashmap = ");  
			      for(Map.Entry n:hm.entrySet()){    
			       System.out.println(n.getKey()+" "+n.getValue());    
			      }
			      
			     //HashTable
			       
			      Hashtable<String,Integer> ht=new Hashtable<String,Integer>();  
			      

			      ht.put("Mohit",3);  
			      ht.put("Harshit",4);  

			      System.out.println("\nThe elements of hashtable = ");  
			      for(Map.Entry hash:ht.entrySet()){    
			       System.out.println(hash.getKey()+" "+hash.getValue());    
			      }
			      
			      
			      //TreeMap
			      
			      TreeMap<String,Integer> t=new TreeMap<String,Integer>();    
			      t.put("Maan",5);    
			      t.put("Nikhil",6);         
			      
			      System.out.println("\nThe elements of treemap = ");  
			      for(Map.Entry tree:t.entrySet()){    
			       System.out.println(tree.getKey()+" "+tree.getValue());    
			      }    

	}

}
