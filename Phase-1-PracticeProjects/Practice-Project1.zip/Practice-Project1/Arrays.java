import java.util.*;
public class Arrays {
	public static void main(String[] args)
	{
		// Single dimensional
		int arr[]= {5,10,15,20,25};
		for(int i=0;i<5;i++) 
		{
		System.out.println("Elements of Array = "+arr[i]);
		}
		
		//Multidimensional 
		int arr1[][] = {{1,2,3,4,5},{6,7,8,9,10}};
		      
		      System.out.println("\nLength of row 1: " + arr1[0].length);
		      System.out.println("\nLength of row 2: " + arr1[1].length);
		      }
}
