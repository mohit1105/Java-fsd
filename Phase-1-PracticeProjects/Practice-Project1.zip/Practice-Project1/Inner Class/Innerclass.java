import java.util.*;
public class Innerclass {

	 int a=5;
	 private int b=7;

	 void display(){  
		 class Inner{  
			 void n(){
				 System.out.println(a);
				 System.out.println(b);
			 }  
	  }  
	  
	  Inner l=new Inner();  
	  l.n(); 
	 }  

	 
	public static void main(String[] args) {
		Innerclass  ob=new Innerclass();  
		ob.display();  
		}


	}

