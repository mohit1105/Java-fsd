import java.util.*;
public class Innerclass1 {
 private int n1= 10;
 int n2 = 20;
	 
	 class up{  
	  void hello(){
		  System.out.println(n1);
		  System.out.println(n2);
		  }  
	 }  


	public static void main(String[] args) {

		Innerclass1 obj=new Innerclass1();
		Innerclass1.up m=obj.new up();  
		m.hello();  
	}
}
