package AccessModifiers;

// All Modifiers are used in same class

class abc{
	public int a = 1;
	protected int b = 2;
	int c = 3;
	private int d = 4;
	void fun()
	{
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}
}
public class Modifiers {
	public static void main(String args[])
	{
		abc obj = new abc();
		obj.fun();
	}

}
