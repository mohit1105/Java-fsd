package AccessModifiers;

// Private modifier not access in same package
// other modifiers are accessible in same package

class a{
	public int a = 1;
	protected int b = 2;
	int c = 3;
	//private int d = 4;
	
}
public class Modifiers1 {
	public static void main(String args[])
	{
		a obj = new a();
		System.out.println(obj.a);
		System.out.println(obj.b);
		System.out.println(obj.c);
		//System.out.println(obj.d);
	}

}