import java.util.*;
public class Constructors {
	int a;
	int age;
	String name;
	// constructor without parameters
	
	public Constructors(){
		a = 10;
	}
	
	//Constructors with parameters
	
	public Constructors(int b,String c) {
		age=b;
		name=c;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Constructors obj = new Constructors();
		Constructors ob = new Constructors(5, "Ram");
		System.out.println(obj.a);
		System.out.println(ob.age+" "+ob.name);
	}

}
