package DsAlgo;
import java.util.*;
public class OrderStatistics {
	public static int kthSmallest(Integer arr[],int k)
	{
		Arrays.sort(arr);
		return arr[k - 1];
	}

	public static void main(String[] args)
	{
		Integer arr[] = new Integer[] { 12, 3, 5, 7, 4, 19, 26 };
		System.out.println("K'th smallest element is " + kthSmallest(arr, 4));
	}
}
