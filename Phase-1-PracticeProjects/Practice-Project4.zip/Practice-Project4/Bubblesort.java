
public class Bubblesort {
	static void bubbleSort(int[] arr) {
	      int n = arr.length;
	      int n1= 0;

	      for(int i = 0; i < n; i++) {
	         for(int j=1; j < (n-i); j++) {
	            if(arr[j-1] > arr[j]) {
	               n1 = arr[j-1];
	               arr[j-1] = arr[j];
	               arr[j] = n1;
	            }
	         }
	      }
	   }
	   public static void main(String[] args) {
	      int arr[] = { 1,4,6,7,88,55,44,41,2,74,63,77,90 };
	      System.out.println("Array Before Bubble Sorting");

	      for(int i = 0; i < arr.length; i++) {
	         System.out.print(arr[i] + " ");
	      }
	      System.out.println();
	      bubbleSort(arr);
	      System.out.println("Array After Bubble Sorting");

	      for(int i = 0; i < arr.length; i++) {
	         System.out.print(arr[i] + " ");
	      }
	   }
}
