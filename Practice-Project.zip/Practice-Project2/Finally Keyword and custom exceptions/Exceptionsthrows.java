
public class Exceptionsthrows {
	void Division(int a, int b) throws ArithmeticException
    {
        int c = a/b;
        System.out.print("\n\tThe result is : " + c);
    }
     public static void main(String[] args)
    {
    	 Exceptionsthrows T = new Exceptionsthrows();
         try
        {
            T.Division(5,0);
        }
        catch(ArithmeticException Ex)
        {
            System.out.print("\n\tError : " + Ex.getMessage());
        }
        System.out.print("\n\tEnd of program.");
    }
}

