import java.util.*;
public class Myclass extends Thread {
	public void run()
	{
		int i=1;
		while(i<12) {
		System.out.println("Thread");
		System.out.println("Running Thread");
		i++;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Myclass obj = new Myclass();
		obj.start();

	}

}
