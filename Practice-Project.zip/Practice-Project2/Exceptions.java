import java.util.Scanner;

public class Exceptions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a, b, c;
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the 1st value = ");
		a=s.nextInt();
		System.out.println("Enter the 2nd value = ");
		b=s.nextInt();

        try
        {
            if(b==0)        
                throw(new ArithmeticException("Cannot divide by zero."));
            else
            {
                c = a / b;
                System.out.println("The result is - " + c);
            }
        }
        catch(ArithmeticException Ex)
        {
            System.out.print("Error - " + Ex.getMessage());
        }

        System.out.println("\nEnd of program.");


	}

}