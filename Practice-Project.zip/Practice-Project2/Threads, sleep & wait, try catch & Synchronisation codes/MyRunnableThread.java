// In this code execute a thread
// Execute try catch exception
// execute sleep and wait function

public class MyRunnableThread implements Runnable{
	public static int msg = 1;

	public void run() {
		while(msg <15)
		{
			try {
				System.out.println("Thread: "+msg);
				msg++;
				Thread.sleep(100);
			}
			catch (Exception e){
				System.out.println(e.getMessage());
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Starting Thread");
		MyRunnableThread obj = new MyRunnableThread();
		Thread t = new Thread(obj);
		t.start();
		while(msg <15)
		{
			try {
				System.out.println("Default Thread: "+msg);
				msg++;
				Thread.sleep(100);
			}
			catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
		System.out.println("Ending of Thread");
	}

}
